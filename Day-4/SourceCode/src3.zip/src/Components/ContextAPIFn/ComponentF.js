import React,{useContext} from 'react'
import { DataContext } from './DataContext'

function ComponentF() {
    const{counter,setCounter}=useContext(DataContext)
    const increment=()=>{
        setCounter(counter+1)
    }
  return (
    <div>
        ComponentF
        <h1>{counter}</h1>
        <button onClick={()=>increment()}>increment</button>
    </div>
  )
}

export default ComponentF