import React from 'react'

const Dsps1=(props)=> {
    const{name,city}=props
  return (
    <div>Id:{props.id}
        <br/>
        Name:{name}
        <br/>
        city:{city}
    </div>
  )
}

export default Dsps1