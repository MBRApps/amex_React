import React, { Component } from 'react'

export class Display extends Component {

  render() {
    const {result}=this.props;
    console.log('Res',result)
    return (
      <div>
        <h1>Dis</h1>
        <ul>
            {
               <h1>Email:{result['email']}</h1>
                
            }
        </ul>
      </div>
    )
  }
}

export default Display