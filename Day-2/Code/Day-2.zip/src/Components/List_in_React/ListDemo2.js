import React from 'react'

function ListDemo2() 
{
    const courselist=['C','C++','Java','Angular','React']
    const courseArray=courselist.map((course,index,finalArray)=>(
        <li key={index}>
            {course}([{finalArray.join(',',course)}])
        </li>
    ))
  return (
    <div>
        <ul>
        {courseArray}
        </ul>
    </div>
  )
}

export default ListDemo2