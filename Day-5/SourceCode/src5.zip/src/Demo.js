import React,{useState} from 'react'

function Demo(props) {
    const[counter,setCounter]=useState(0)
    function increment()
    {
        setCounter(counter+1)
    }
  return (
    <div>
        <h1>Welcome {props.username}</h1>
        <h2>Count:{counter}</h2>
        <button id="btnIncrement" onClick={()=>increment()}>Increment</button>
    </div>
  )
}

export default Demo