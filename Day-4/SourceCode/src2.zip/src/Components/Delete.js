import React,{useEffect} from 'react'
import {useParams} from 'react-router-dom'

function Delete() {
    const{id}=useParams()

    const xhr=new XMLHttpRequest();
    xhr.open("DELETE","https://reqres.in/api/users/"+id,true)
    xhr.onreadystatechange=()=>{
        if(xhr.readyState==4 && xhr.status==204)
        {
            alert('Record Deleted Successfully')
            window.location="../"
        }
    }
    xhr.send()
    
   
  return (
    <div>Delete</div>
  )
}

export default Delete