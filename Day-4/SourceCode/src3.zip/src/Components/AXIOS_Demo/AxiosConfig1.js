import axios from "axios";

import React from 'react'

const AxiosConfig1=axios.create({
    baseURL:'',
    headers:{}
})

export default AxiosConfig1