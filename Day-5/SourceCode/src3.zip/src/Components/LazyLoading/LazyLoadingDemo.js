import React, { Suspense, lazy, useState } from 'react'

const LazyComponent=lazy(()=>import('./Demo'))
function LazyLoadingDemo() {
    const[showlazycomponent,setvisibility]=useState(false)
    const showcomponent=()=>{
        setvisibility(true)
    }
  return (
    <div>
        <button onClick={showcomponent}>Show</button>
        <Suspense fallback={<div>loading...</div>}>
            {
                showlazycomponent?<LazyComponent/>:null
            }
            
        </Suspense>
        
    </div>
  )
}

export default LazyLoadingDemo