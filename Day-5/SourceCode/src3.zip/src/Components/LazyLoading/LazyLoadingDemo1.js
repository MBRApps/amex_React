import React, { Suspense, lazy, useEffect, useState } from 'react'

const LazyComponent=lazy(()=>import('./Demo'))
function LazyLoadingDemo1() 
{
  const[showloader,setShowLoader]=useState(true)
  useEffect(()=>{
    const delay=setTimeout(() => {
        setShowLoader(false)
    }, 5000);
    return()=>clearTimeout(delay)
  },[])
  return (
    <div>
        <Suspense fallback={<div>Loading</div>}>
            {
                showloader?
                <div><h1>Loading component....</h1></div>:
                <LazyComponent/>
            }
        </Suspense>
    </div>
  )
}

export default LazyLoadingDemo1