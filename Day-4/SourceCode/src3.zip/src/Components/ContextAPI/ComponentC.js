import React, { Component } from 'react'
import { UserConsumer } from './UserContext'

export class ComponentC extends Component {
  render() {
    return (
      <div>
        ComponentC
        <UserConsumer>
            {
                (data)=>{
                    const{counter,setCounter}=data
                    return <div>
                        <h1>{counter}</h1>
                        <button onClick={()=>setCounter(counter+1)}>increment</button>
                    </div>
                }
            }
        </UserConsumer>
      </div>
    )
  }
}

export default ComponentC