import React, { Component } from 'react'

export class Student extends Component {
    constructor() {
      super()
    
      this.state = {
         name:'John'
      }
    }
  render() {
    return (
      <div>
        Name:{this.state.name}
      </div>
    )
  }
}

export default Student