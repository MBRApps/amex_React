import React from 'react'
//import stevejobsimg from '.../public/logo192.png'

function ImagesDemo() {
  return (
    <div>
        <img src="/logo192.png"/>
    </div>
  )
}

export default ImagesDemo