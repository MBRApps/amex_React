import React from 'react'

const mystyles={
    color:'orange',
    fontSize:'38px'
}
function CSSDemo2() {
  return (
    <div>
        <h1 style={mystyles}>Sample Text Here</h1>
    </div>
  )
}

export default CSSDemo2