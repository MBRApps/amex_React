import React,{useEffect} from 'react'
import {useParams} from 'react-router-dom'

function Delete() {
    const{id}=useParams()

    
    fetch('https://reqres.in/api/users/'+id,{method:'DELETE'})
    .then(result=>{
        if(result.status==204)
        {
            alert('Record Deleted Successfully!')
            window.location='../'
        }
    })
  return (
    <div>Delete</div>
  )
}

export default Delete