import React,{useState} from 'react'

function UseState1() {
    const[count,setCount]=useState(0)

    function Increment()
    {
        setCount(count+1)
    }
  return (
    <div>
        <h1>{count}</h1>
        <br/>
        <button onClick={()=>Increment()}>Increment</button>
    </div>
  )
}
export default UseState1