import logo from './logo.svg';
import './App.css';
import ProductComponent from './Components/ProductComponent';
import {Provider} from 'react-redux'
import {Store} from './Redux/Store'
import Navbar from './Components/Navbar';

function App() {
  return (
   <>
   <Provider store={Store}>
      <Navbar/>
      <ProductComponent/>
   </Provider>
   
   </>
      
  );
}

export default App;
