import React, { Component } from 'react'
import {Link} from 'react-router-dom'

export class Home extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         users:[]
      }
    }
    getData()
    {
        fetch('http://localhost:3200/posts',{method:'GET'})
        .then(result=>{
            return result.json()})
            .then(res=>{
                //console.log(res.data)
                this.setState({users:res})
            })
         
    }
    componentDidMount()
    {
        this.getData();
    }
  render() {
    const{users}=this.state
    return (
      <div className='container mt-5'>
        <div className='container'>
            <Link to='/add' className='btn btn-success'>Add User</Link>
        </div>
            <table className='mt-3 table table-responsive table-bordered table-hover'>
                <thead className='table-success'>
                    <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        users.length?
                        users.map((user,index)=>
                        <tr key={index}>
                            <td>{user.id}</td>
                            <td>{user.first_name} {user.last_name}</td>
                            <td>{user.email}</td>
                            <td>
                                <Link to={`/edit/${user.id}`} className='btn btn-warning'>Edit</Link>
                                &nbsp;
                                <Link to={`/delete/${user.id}`} className='btn btn-danger'>Delete</Link>
                               
                            </td>
                        </tr>
                        )
                        :null
                    }
                </tbody>
            </table>
      </div>
    )
  }
}

export default Home