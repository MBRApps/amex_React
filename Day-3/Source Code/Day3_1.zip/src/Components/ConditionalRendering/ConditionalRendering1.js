import React, { Component } from 'react'

export class ConditionalRendering1 extends Component 
{
    constructor(props) {
      super(props)
    
      this.state = {
         isLoggedInn:false
      }
    }
  render() {
    if(this.state.isLoggedInn)
    {
        return(
            <div>
                <h1>Welcome Admin</h1>
            </div>
        )
    }
    else{
        return(
            <div>
                <h1>Welcome Guest</h1>
            </div>
        )
    }
  }
}

export default ConditionalRendering1