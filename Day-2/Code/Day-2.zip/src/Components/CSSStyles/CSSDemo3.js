import React from 'react'
import styles from './customStyles.module.css'

function CSSDemo3() {    
  return (
    <div>
        <h1 className={styles.redText}>Sample Text</h1>
        <h1 className={styles.blueText}>Sample Text</h1>
    </div>
  )
}

export default CSSDemo3