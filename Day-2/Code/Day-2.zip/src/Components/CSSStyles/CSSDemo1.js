import React from 'react'
import './mystyles.css'

function CSSDemo1(props) {
    const cssClassName=props.status?'online':'offline'
  return (
    <div>
        <h1 className={cssClassName}>Sample Text</h1>
    </div>
  )
}

export default CSSDemo1