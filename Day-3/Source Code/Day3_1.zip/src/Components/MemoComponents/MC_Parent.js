import React, { Component } from 'react'
import MC_Child from './MC_Child'

export class MC_Parent extends Component 
{
    constructor(props) {
      super(props)
    
      this.state = {
         name:'john'
      }
    }
    componentDidMount()
    {
        setInterval(()=>{
            this.setState({name:'john'})
        },2000)
    }
  render() {
    console.log('****************Parent Component**********************')
    return (
      <div>
        <h6>Parent Component</h6>
        <MC_Child value={this.state.name}/>
      </div>
    )
  }
}

export default MC_Parent