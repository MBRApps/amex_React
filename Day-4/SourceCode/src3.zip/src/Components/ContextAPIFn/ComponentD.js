import React from 'react'
import ComponentE from './ComponentE'

function ComponentD() {
  return (
    <div>
        ComponentD
        <ComponentE/>
    </div>
  )
}

export default ComponentD