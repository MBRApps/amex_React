import React, { Component } from 'react'
import ComponentB from './ComponentB'

export class ComponentA extends Component 
{
    constructor(props) 
    {
      console.log("---------Component-A Constructor--------")
      super(props)
    
      this.state = {
         name:'John'
      }
    }
    static getDerivedStateFromProps(props,state)
    {
        console.log("---------Component-A getDerivedStateFromProps--------")
        // if(state.name=='John')
        // {
        //     return {name:'Hero'}
        // }
        // else{
        // return {
        //     name:'Steve'
        // };
        return null;
    
    }
    componentDidMount()
    {
        console.log("---------Component-A componentDidMount--------")
    }

    shouldComponentUpdate(nextProps,nextState)
    {
        console.log("---------Component-A shouldComponentUpdate--------")
        return true;
    }
    getSnapshotBeforeUpdate(prevPros,prevState)
    {
        console.log("---------Component-A getSnapshotBeforeUpdate--------")
        return null;
    }
    componentDidUpdate()
    {
        console.log("---------Component-A componentDidUpdate--------")
    }

    changeName=()=>{
        this.setState({name:'Harry'})
    }
  render() {
    console.log("---------Component-A render--------")
    return (
      <div>
        ComponentA:{this.state.name}
        <br/>
        <button onClick={this.changeName}>Change Name</button>
        <br/>
        <ComponentB/>
      </div>
    )
  }
}

export default ComponentA