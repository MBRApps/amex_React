import logo from './logo.svg';
import './App.css';
import ImagesDemo from './Components/UsingImages/ImagesDemo';
import ComponentA from './Components/ContextAPI/ComponentA';
import { UserProvider } from './Components/ContextAPI/UserContext';
import {useState} from 'react'
import ComponentD from './Components/ContextAPIFn/ComponentD';
import { DataContextProvider } from './Components/ContextAPIFn/DataContext';
import Demo from './Components/HigherOrderComponents/Demo';
import AxiosGet from './Components/AXIOS_Demo/AxiosGet';
import AxiosPost from './Components/AXIOS_Demo/AxiosPost';
import AxiosPut from './Components/AXIOS_Demo/AxiosPut';
import AxiosDelete from './Components/AXIOS_Demo/AxiosDelete';

function App() {
    return( 
    <>
      {/* <ImagesDemo/> */}
{/*       
      <DataContextProvider>
           <ComponentD/>
      </DataContextProvider> */}
         
          {/* <Demo/> */}
          {/* <AxiosGet/> */}
          {/* <AxiosPost/> */}
          <AxiosPut/> 
          {/* <AxiosDelete/> */}
     
       
    </>
    )
}

export default App;
