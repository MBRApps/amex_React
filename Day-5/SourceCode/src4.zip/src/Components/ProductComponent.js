import React from 'react'
import ProductsData from '../Data/ProductsData.json'
import {useDispatch} from 'react-redux'
import { addToCart, removeFromCart } from '../Redux/CartReducer'

const ProductComponent=()=> 
{
    const dispatch=useDispatch()
  return (
    <div>
        <div className='container mt-5'>
            <div className='row'>
                {
                ProductsData.Products.map((x,i)=>
                <div className='col' key={i}>
                    <div className='card'>
                        <img src="https://rukminim2.flixcart.com/image/850/1000/j7ksia80/mobile/2/r/q/apple-iphone-8-mq6m2hn-a-original-imaexsbzzv79efkp.jpeg?q=20" height="100" width="80"/>
                        <p className='card-title'>
                            {x.name} | {x.price}
                        </p>
                        <div className='card-body mt-3'>
                            <button className='btn btn-primary'
                             onClick={()=>dispatch(addToCart({id:x.id,name:x.name,price:x.price}))}>Add to Cart</button>
                            <br/><br/>
                            <button className='btn btn-primary'
                            onClick={()=>dispatch(removeFromCart({id:x.id,name:x.name,price:x.price}))}>Remove from Cart</button>
                        </div>
                    </div>
                </div>
                )
                }
            </div>
        </div>
    </div>
  )
}

export default ProductComponent