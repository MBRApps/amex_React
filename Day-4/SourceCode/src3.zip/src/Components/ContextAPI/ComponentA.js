import React, { Component } from 'react'
import ComponentB from './ComponentB'
import { UserProvider } from './UserContext'

export class ComponentA extends Component 
{
    constructor(props) {
      super(props)
    
      this.state = {
         count:0
      }
    }
    increment=(inp)=>{
        this.setState({count:inp})
    }
  render() {
    return (
      <div>
        ComponentA
        <UserProvider value={{counter:this.state.count,setCounter:this.increment}}>
            <ComponentB/>
        </UserProvider>
        
      </div>
    )
  }
}

export default ComponentA