import React from 'react'
import C2P_Child from './C2P_Child'

function Callback(data)
{
    return(
        <div>Message Fro Child:{data}</div>
    )
}
function C2P_Parent() 
{
  return (
    <div>
        <C2P_Child handler={Callback}/>
    </div>
  )
}

export default C2P_Parent