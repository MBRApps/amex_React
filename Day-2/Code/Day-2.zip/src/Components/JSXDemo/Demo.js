import React from 'react'

const Demo=()=> {
  return React.createElement('div',null,
  React.createElement('h1',{id:'samplehead1'},'This is from heading tag')
  )

}

export default Demo