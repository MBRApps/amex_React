import React from 'react'
import {useSelector} from 'react-redux'

function Navbar() {
    const cartCount=useSelector((state)=>state.Cart.cartValues.length)
    useSelector((state)=>console.log(state))
    //const cartCount=0
    const CartTotal=useSelector((state)=>state.Cart.total)

  return (
    <div>
        <nav className='navbar navbar-dark bg-dark'>
            <div className='d-inline p-2 navbar-nav mx-auto'>
                <span className='btn btn-primary'>
                    Item Count:{cartCount}
                </span>
                &nbsp;
                <span className='btn btn-primary'>
                    Total:{CartTotal}
                </span>
            </div>
        </nav>
    </div>
  )
}

export default Navbar