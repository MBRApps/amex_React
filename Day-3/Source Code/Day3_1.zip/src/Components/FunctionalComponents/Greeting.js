import React from 'react'

const Greeting=()=> {
  return (
    <div>
        <h1>Good Evening</h1>
    </div>
  )
}

export default Greeting