import logo from './logo.svg';
import './App.css';
import Welcome from './Components/FunctionalComponents/Welcome';
import Greeting from './Components/FunctionalComponents/Greeting';
import Greet from './Components/ClassComponents/Greet';
import Demo from './Components/JSXDemo/Demo';
import Product from './Components/Props_and_State/Product';
import Employee from './Components/Props_and_State/Employee';
import Student from './Components/Props_and_State/Student';
import Counter from './Components/Props_and_State/Counter';
import Test from './Components/Props_and_State/Test';
import Dsps1 from './Components/DeStructuringPropsAndState/Dsps1';
import Dsps2 from './Components/DeStructuringPropsAndState/Dsps2';
import EventBinding1 from './Components/EventBindings/EventBinding1';
import EventBinding2 from './Components/EventBindings/EventBinding2';
import EventBinding3 from './Components/EventBindings/EventBinding3';
import EventBinding4 from './Components/EventBindings/EventBinding4';
import ParentComponent from './Components/ComponentCommunication/ParentComponent';


function App() {
  return (
    <div>
      {/* <Product name="Iphone 15" price="98000" category="Electronics"/>
      <Product name="Iphone 15 Pro" price="136000" category="Electronics"/>

      <Employee name="Steve" designation="Manager"/> */}

      {/* <Student/> */}
      {/* <Counter/> */}
      {/* <Test/> */}

      {/* <Dsps1 id="101" name="John" city="delhi"/>

      <Dsps2 id="101" name="John" city="delhi"/> */}
      {/* <EventBinding1/> */}
      {/* <EventBinding2/> */}
      {/* <EventBinding3/> */}
      {/* <EventBinding4/> */}
      <ParentComponent/>
    </div>
  
  );
}

export default App;
