import axios from 'axios'
import React, { Component } from 'react'
import Display from './Display'

export class AxiosPut extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         userdata:[]
      }
    }
    
    componentDidMount()
    {
        debugger;
        const data=[]
        axios.put('/api/users/9',{email:'test@gmail.com',first_name:'',last_name:''})
        .then(res=>{
            this.setState({userdata:res.data})
            console.log(res)
        },()=>{
            console.log('Reject')
        })
        .catch(err=>{

        })
        
    }
  render() {
    return (
      <div>
        AxiosPut
        <Display result={this.state.userdata}/>
    </div>
    )
  }
}

export default AxiosPut