import React from 'react'
import ComponentF from './ComponentF'

function ComponentE() {
  return (
    <div>
        ComponentE
        <ComponentF/>
    </div>
  )
}

export default ComponentE