import React from 'react'

function TBody() {
  return (
    <React.Fragment>
        <tbody>
            <tr>
                <td>1</td>
                <td>Angular Js</td>
            </tr>
            <tr>
                <td>2</td>
                <td>React Js</td>
            </tr>
            <tr>
                <td>3</td>
                <td>Vue Js</td>
            </tr>
        </tbody>
    </React.Fragment>
  )
}

export default TBody
