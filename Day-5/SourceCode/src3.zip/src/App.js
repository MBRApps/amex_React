import logo from './logo.svg';
import './App.css';
import LazyLoadingDemo from './Components/LazyLoading/LazyLoadingDemo';
import LazyLoadingDemo1 from './Components/LazyLoading/LazyLoadingDemo1';
import ReduxDemo from './Components/ReactRedux/ReduxDemo';
import { Provider } from 'react-redux';
import Store from './Components/ReactRedux/Store';

function App() {
  return (
    <>
    <Provider store={Store}>
        <ReduxDemo/>        
    </Provider>
     
    </>
  );
}

export default App;
