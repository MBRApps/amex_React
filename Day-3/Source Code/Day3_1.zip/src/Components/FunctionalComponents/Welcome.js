import React from 'react'

function Welcome() {
  return (
    <>
        <h1>Welcome User!</h1>
        <h2>This is sample text</h2>
    </>
    
  )
}

export default Welcome