import React, { Component } from 'react'

export class EventBinding2 extends Component 
{
    constructor(props) {
      super(props)
    
      this.state = {
         msg:'Good Afternoon',
         name:'John'
      }
    }
    changeMsg()
    {
        this.setState({msg:'Good Evening!'})
    }
  render() {
    return (
      <div>
        <h1>Dear {this.state.name},{this.state.msg}</h1>
        <button onClick={()=>this.changeMsg()}>Change Message</button>
      </div>
    )
  }
}

export default EventBinding2