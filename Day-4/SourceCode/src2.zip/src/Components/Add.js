import React, { Component } from 'react'

export class Add extends Component 
{
    constructor(props) {
      super(props)
    
      this.state = {
         first_name:'',last_name:'',email:''
      }
    }
    changeHandler=(e)=>{
        this.setState({[e.target.name]:e.target.value})
    }
    submitHandler=(e)=>{
        e.preventDefault()
        console.log(this.state)
        const xhr=new XMLHttpRequest();
        xhr.open("POST","https://reqres.in/api/users",true);
        xhr.setRequestHeader("Content-Type","application/json");

        xhr.onreadystatechange=()=>{
            if(xhr.readyState==4 && xhr.status==201)
            {
                alert('Record Saved Successfully!')
                window.location='./'
            }
        }
        xhr.onerror=()=>{
            
        }

        xhr.send(JSON.stringify(this.state))

       
    }
  render() {
    return (
      <div className='container mt-5'>
        <form onSubmit={this.submitHandler}>
        <div className='alert alert-success'>Add User</div>
        <div className='row'>
            <div className='col'>
                <input type="text" name="first_name" className='form-control'
                placeholder='Enter First Name' defaultValue={this.state.first_name} onChange={this.changeHandler}/>
            </div>
            <div className='col'>
                <input type="text" name="last_name" className='form-control'
                placeholder='Enter Last Name' defaultValue={this.state.last_name} onChange={this.changeHandler}/>
            </div>
        </div>
        <div className='row mt-3'>
            <div className='col'>
                <input type="email" name="email" className='form-control'
                placeholder='Enter E-Mail' defaultValue={this.state.email} onChange={this.changeHandler}/>
            </div>           
        </div>
        <div className='row mt-3'>
            <div className='col'>
                <input type="submit" className='btn btn-success'/>
            </div>           
        </div>
        </form>
      </div>
    )
  }
}

export default Add