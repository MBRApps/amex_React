import React, { useEffect, useRef } from 'react'

function RefDemo1() {
    const nameRef=useRef();
    useEffect(()=>{
        nameRef.current.placeholder="Enter Name Here"
    },[])
    function clickHandler()
    {
        alert(nameRef.current.value)
    }
  return (
    <div>
        <input type="text" name="txtName" ref={nameRef}/>
        <br/>
        <button onClick={()=>clickHandler()}>Submit</button>
    </div>
  )
}

export default RefDemo1