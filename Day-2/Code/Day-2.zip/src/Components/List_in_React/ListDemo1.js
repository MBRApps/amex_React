import React from 'react'

function ListDemo1() {
    const courselist=['C','C++','Java','Angular','React']
  return (
    <div>
        <ol>
            {
                courselist.map((course,index)=>
                    <li key={index}>{course}</li>
                    )
            }
        </ol>
    </div>
  )
}

export default ListDemo1