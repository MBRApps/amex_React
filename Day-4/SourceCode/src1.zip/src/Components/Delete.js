import React,{useEffect} from 'react'
import {useParams} from 'react-router-dom'

function Delete() {
    const{id}=useParams()

    
    fetch('http://localhost:3200/posts/'+id,{method:'DELETE'})
    .then(result=>{
      console.log(result.status)
        if(result.status==200)
        {
            alert('Record Deleted Successfully!')
            window.location='../'
        }
    })
  return (
    <div>Delete</div>
  )
}

export default Delete