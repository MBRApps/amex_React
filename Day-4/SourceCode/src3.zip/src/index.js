import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import axios from 'axios';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode> 
);


axios.interceptors.request.use((req)=>{
  req.baseURL="https://reqres.in/"
  req.headers['Content-Type']="application/json"
  //req.headers['Authorization']='Bearer'+"";
  return req;
})

axios.interceptors.response.use((res)=>{
    if(res.status==201)
    {
      console.log('Success')
    }
    return res;
},
(error)=>{
  if(error.response && error.response.status==401)
  {
    console.log('We Are UnAuthorised')
  }
})



 reportWebVitals();
