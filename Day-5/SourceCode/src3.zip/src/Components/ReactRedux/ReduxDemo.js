import React from 'react'
import {connect} from 'react-redux'
import {IncAction,DecAction} from './Actions'

function ReduxDemo(props) {
  return (
    <div>
        <h1>{props.counter}</h1>
        <button onClick={()=>props.DecAction(5)}>Decrement</button>
        <button onClick={()=>props.IncAction(5)}>Increment</button>
    </div>
  )
}

const mapStateToProps=(state)=>(
    {counter:state}
)

export default connect(mapStateToProps,{IncAction,DecAction}) (ReduxDemo)