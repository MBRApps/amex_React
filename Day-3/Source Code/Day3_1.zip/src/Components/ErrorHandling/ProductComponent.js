import React from 'react'

function ProductComponent(props) 
{
  if(props.children!='Electronics')
  {
      throw new Error('Invalid Category')
  }
  return (
    <div>
        <h1>Name:{props.name}</h1>
        <h2>Price:{props.price}</h2>
        <h3>Category:{props.children}</h3>
        <hr/>
    </div>
  )
}

export default ProductComponent