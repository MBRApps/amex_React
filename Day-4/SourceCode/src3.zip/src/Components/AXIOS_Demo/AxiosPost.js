import axios from 'axios'
import React, { Component } from 'react'

export class AxiosPost extends Component {
    componentDidMount()
    {
        axios.post('/api/users',{email:'test@gmail.com',first_name:'',last_name:''})
        .then(res=>{
            console.log(res.data)
        })
    }
  render() {
    return (
      <div>AxiosPost</div>
    )
  }
}

export default AxiosPost