import React, { Component } from 'react'

export class Dsps2 extends Component {
   
  render() {
    const{name,city}=this.props
    return (
      <div>
        Name:{name}
        <br/>
        City:{city}
      </div>
    )
  }
}

export default Dsps2