import React, { Component } from 'react'

export class ComponentB extends Component 
{
    constructor(props) 
    {
      console.log("---------Component-B Constructor--------")
      super(props)
    
      this.state = {
         name:'John'
      }
    }
    static getDerivedStateFromProps(props,state)
    {
        console.log("---------Component-B getDerivedStateFromProps--------")
        // if(state.name=='John')
        // {
        //     return {name:'Hero'}
        // }
        // else{
        // return {
        //     name:'Steve'
        // };
        return null;
    
    }
    componentDidMount()
    {
        console.log("---------Component-B componentDidMount--------")
    }

    shouldComponentUpdate(nextProps,nextState)
    {
        console.log("---------Component-B shouldComponentUpdate--------")
        return true;
    }
    getSnapshotBeforeUpdate(prevPros,prevState)
    {
        console.log("---------Component-B getSnapshotBeforeUpdate--------")
        return null;
    }
    componentDidUpdate()
    {
        console.log("---------Component-B componentDidUpdate--------")
    }

    changeName=()=>{
        this.setState({name:'Harry'})
    }
  render() {
    console.log("---------Component-B render--------")
    return (
      <div>
        ComponentA:{this.state.name}
        <br/>
        <button onClick={this.changeName}>Change Name</button>
        <br/>
        
      </div>
    )
  }
}

export default ComponentB