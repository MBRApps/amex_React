import React, { Component } from 'react'

export class BasicForm1 extends Component 
{
    constructor(props) {
      super(props)
    
      this.state = {
         name:'',
         mobile:'',
         city:''
      }
    }

  changeHandler=(event)=>
  {        
        this.setState({[event.target.name]:event.target.value})
  }

  submitHandler=(event)=>{
        event.preventDefault();
        console.log(this.state)
  }

  render() {
    return (
      <div className='container'>
        <div className='mt-2 alert alert-success'>
            <h4>Add User</h4>
        </div>
        <form onSubmit={this.submitHandler}>
           <div className='row mt-5'>
                <div className='col'>
                    <input type="text" placeholder='Enter Name Here' className='form-control' 
                    defaultValue={this.state.name} onChange={this.changeHandler}
                     name="name"/>
                </div>
                <div className='col'>
                    <input type="text" placeholder='Enter Mobile No. Here' className='form-control'
                     defaultValue={this.state.mobile} onChange={this.changeHandler} 
                     name="mobile"/>
                </div>
           </div>
           <div className='row mt-3'>
                <div className='col'>
                    <select className='form-select' defaultValue={this.state.city}
                     onChange={this.changeHandler} name="city">
                        <option value="">--select--</option>
                        <option value="MUM">Mumbai</option>
                        <option value="DEL">Delhi</option>
                        <option value="CHN">Chennai</option>
                    </select>
                </div>
           </div>
           <div className='row mt-3'>
                <div className='col'>
                    <input type="submit" className='btn btn-success'/>
                </div>
           </div>
        </form>
      </div>
    )
  }
}

export default BasicForm1