import React from 'react'
import ReactDOM  from 'react-dom'

function PortalsDemoComponent() {
  return ReactDOM.createPortal(
    <div>
        <h1>This is Sample Text</h1>
    </div>,
    document.getElementById('custom')
  )
}

export default PortalsDemoComponent