import React, { useEffect, useState } from 'react'

function UseEffectDemo1() 
{
    const[count,setcount]=useState(0)
    const[count1,setcount1]=useState(0)
    useEffect(()=>{
        console.log('Use Effect Invoked!')
    },[increment,count1])
    function increment()
    {
        setcount(count+1)
    }
  return (
    <div>
        {count}
        <button onClick={()=>increment()}>Increment</button>
    </div>
  )
}

export default UseEffectDemo1