import {fireEvent, render,screen} from '@testing-library/react'
import Demo from './Demo'

test('#01',()=>{
    render(<Demo username="admin"/>);
    const linkElement=screen.getByText('Welcome admin')
    expect(linkElement).toBeInTheDocument();
});

test('#02',()=>{
    render(<Demo/>);
    const linkElement=screen.getByText('Count:0')
    expect(linkElement).toBeInTheDocument();
});

test('#03',()=>{
    render(<Demo/>);
    const btn=screen.getByRole('button')
    fireEvent.click(btn)
    const linkElement=screen.getByText('Count:1')
    expect(linkElement).toBeInTheDocument();
});