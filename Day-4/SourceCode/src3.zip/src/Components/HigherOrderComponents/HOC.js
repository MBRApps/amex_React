import React from 'react'

const HOC=(Component)=> {
  return (
    class extends React.Component
    {
        state={authStatus:true}
        render(){
            return(
                this.state.authStatus?<Component/>:
                <h1>Sorry! You can't access this component</h1>
            )
        }
    }
  )
}

export default HOC