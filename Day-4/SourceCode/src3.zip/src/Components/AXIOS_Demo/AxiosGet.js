import React, { Component } from 'react'
import axios from 'axios'
import AxiosConfig1 from './AxiosConfig1'

export class AxiosGet extends Component {
    componentDidMount()
    {
        axios.get('api/users?page=2')
        .then(res=>{
            console.log(res.data.data)
        })
        //AxiosConfig1.get()
    }
  render() {
    return (
      <div>AxiosGet</div>
    )
  }
}

export default AxiosGet