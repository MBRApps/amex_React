import React, { Component } from 'react'
import FRInput from './FRInput'

export class FRParent extends Component 
{
    constructor(props) {
      super(props)
      this.nameref=React.createRef()
    }
    clickHandler=()=>{
        alert(this.nameref.current.value)
    }
  render() {
    return (
      <div>
        <FRInput ref={this.nameref} value="sample text"/>
        <button onClick={this.clickHandler}>Submit</button>
      </div>
    )
  }
}

export default FRParent