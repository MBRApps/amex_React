import React from 'react'
import HOC from './HOC'

function Demo() {
  return (
    <div>Demo</div>
  )
}

export default HOC(Demo)