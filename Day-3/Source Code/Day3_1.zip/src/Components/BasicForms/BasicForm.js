import React, { Component } from 'react'

export class BasicForm extends Component 
{
    constructor(props) {
      super(props)
    
      this.state = {
         name:'',
         mobile:'',
         city:''
      }
    }

  changeNameHandler=(event)=>
  {
        //console.log(event.target)
        this.setState({name:event.target.value})
  }

  changeMobileHandler=(event)=>
  {
        //console.log(event.target)
        this.setState({mobile:event.target.value})
  }
  changeCityHandler=(event)=>
  {
        //console.log(event.target)
        this.setState({city:event.target.value})
  }
  submitHandler=(event)=>{
        event.preventDefault();
        console.log(this.state)
  }

  render() {
    return (
      <div className='container'>
        <div className='mt-2 alert alert-success'>
            <h4>Add User</h4>
        </div>
        <form onSubmit={this.submitHandler}>
           <div className='row mt-5'>
                <div className='col'>
                    <input type="text" placeholder='Enter Name Here' className='form-control' 
                    defaultValue={this.state.name} onChange={this.changeNameHandler}/>
                </div>
                <div className='col'>
                    <input type="text" placeholder='Enter Mobile No. Here' className='form-control'
                     defaultValue={this.state.mobile} onChange={this.changeMobileHandler}/>
                </div>
           </div>
           <div className='row mt-3'>
                <div className='col'>
                    <select className='form-select' defaultValue={this.state.city}
                     onChange={this.changeCityHandler}>
                        <option value="">--select--</option>
                        <option value="MUM">Mumbai</option>
                        <option value="DEL">Delhi</option>
                        <option value="CHN">Chennai</option>
                    </select>
                </div>
           </div>
           <div className='row mt-3'>
                <div className='col'>
                    <input type="submit" className='btn btn-success'/>
                </div>
           </div>
        </form>
      </div>
    )
  }
}

export default BasicForm