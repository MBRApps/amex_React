import React from 'react'

function ListDemo3() {
    const CourseList=[
        {id:101,title:'C',duration:30},
        {id:102,title:'C++',duration:45},
        {id:103,title:'Java',duration:60},
        {id:104,title:'SQL',duration:45},
        {id:105,title:'Angular',duration:60},
    ]
  return (
    <div>
        <table className='table table-responsive table-bordered table-hover'>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Duration</th>
                </tr>
            </thead>
            <tbody>
                {
                    CourseList.map((course,index)=>
                    <tr key={index}>
                        <td>{course.id}</td>
                        <td>{course.title}</td>
                        <td>{course.duration}</td>
                    </tr>
                    )
                }
            </tbody>
        </table>
    </div>
  )
}

export default ListDemo3