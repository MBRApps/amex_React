import logo from './logo.svg';
import './App.css';
import Welcome from './Components/FunctionalComponents/Welcome';
import Greeting from './Components/FunctionalComponents/Greeting';
import Greet from './Components/ClassComponents/Greet';
import Demo from './Components/JSXDemo/Demo';
import Product from './Components/Props_and_State/Product';
import Employee from './Components/Props_and_State/Employee';
import Student from './Components/Props_and_State/Student';
import Counter from './Components/Props_and_State/Counter';
import Test from './Components/Props_and_State/Test';
import Dsps1 from './Components/DeStructuringPropsAndState/Dsps1';
import Dsps2 from './Components/DeStructuringPropsAndState/Dsps2';
import EventBinding1 from './Components/EventBindings/EventBinding1';
import EventBinding2 from './Components/EventBindings/EventBinding2';
import EventBinding3 from './Components/EventBindings/EventBinding3';
import EventBinding4 from './Components/EventBindings/EventBinding4';
import ParentComponent from './Components/ComponentCommunication/ParentComponent';
import ConditionalRendering1 from './Components/ConditionalRendering/ConditionalRendering1';
import ConditionalRendering2 from './Components/ConditionalRendering/ConditionalRendering2';
import ConditionalRendering3 from './Components/ConditionalRendering/ConditionalRendering3';
import ConditionalRendering4 from './Components/ConditionalRendering/ConditionalRendering4';
import ListDemo1 from './Components/List_in_React/ListDemo1';
import ListDemo2 from './Components/List_in_React/ListDemo2';
import ListDemo3 from './Components/List_in_React/ListDemo3';
import CSSDemo1 from './Components/CSSStyles/CSSDemo1';
import CSSDemo2 from './Components/CSSStyles/CSSDemo2';
import CSSDemo3 from './Components/CSSStyles/CSSDemo3';
import BasicForm from './Components/BasicForms/BasicForm';
import BasicForm1 from './Components/BasicForms/BasicForm1';
import ComponentA from './Components/ComponentLifeCycle/ComponentA';
import Table from './Components/Fragments/Table';
import UseState1 from './Components/useStateDemo/UseState1';
import UseState2 from './Components/useStateDemo/UseState2';
import UseEffectDemo1 from './Components/UseEffectDemo/UseEffectDemo1';


function App() {

  return (
    <div>
      {/* <Product name="Iphone 15" price="98000" category="Electronics"/>
      <Product name="Iphone 15 Pro" price="136000" category="Electronics"/>

      <Employee name="Steve" designation="Manager"/> */}

      {/* <Student/> */}
      {/* <Counter/> */}
      {/* <Test/> */}

      {/* <Dsps1 id="101" name="John" city="delhi"/>

      <Dsps2 id="101" name="John" city="delhi"/> */}
      {/* <EventBinding1/> */}
      {/* <EventBinding2/> */}
      {/* <EventBinding3/> */}
      {/* <EventBinding4/> */}
      {/* <ParentComponent/> */}
      {/* <ConditionalRendering1/> */}
      {/* <ConditionalRendering2/> */}
      {/* <ConditionalRendering3/> */}
      {/* <ConditionalRendering4/> */}
      {/* <ListDemo1/> */}
      {/* <ListDemo2/> */}
      {/* <ListDemo3/> */}
      {/* <CSSDemo1 status={false}/> */}
      {/* <CSSDemo2/> */}
      {/* <CSSDemo3/> */}
      {/* <BasicForm/> */}
      {/* <BasicForm1/> */}
      {/* <ComponentA/> */}
      {/* <Table/> */}
      {/* <UseState1/> */}
      {/* <UseState2/> */}
      <UseEffectDemo1/>
    </div>
  
  );
}

export default App;
