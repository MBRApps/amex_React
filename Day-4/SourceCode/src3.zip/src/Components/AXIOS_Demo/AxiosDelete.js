import axios from 'axios'
import React, { Component } from 'react'

export class AxiosDelete extends Component {
    componentDidMount()
    {
        axios.delete('/api/users/5')
        .then(res=>{
            console.log(res)
        })
    }
  render() {
    return (
      <div>AxiosDelete</div>
    )
  }
}

export default AxiosDelete