import React from 'react'

function MC_Child(props) 
{
    console.log('*************Child Component****************')
  return (   
    <div>
        <h6>Child Component</h6>
        <h2>Input:{props.value}</h2>
    </div>
  )
}

export default React.memo(MC_Child)